def listar_empleados(empleados):
    if not empleados:
        print("No hay empleados registrados.")
        return []

    for empleado in empleados:
        print(
            f"Nombre: {empleado['nombre']}, Edad: {empleado['edad']}, "
            f"Salario: {empleado['salario']}, Departamento: {empleado['dpto']}"
        )
    return empleados


def lista_empleados(empleados):
    return listar_empleados(empleados)


def buscar_por_departamento(empleados, dpto_a_buscar):
    resultados = [
        empleado for empleado in empleados if empleado["dpto"].lower() == dpto_a_buscar.lower()
    ]

    if not resultados:
        print(f"No se encontraron empleados en el departamento '{dpto_a_buscar}'.")
        return []

    for empleado in resultados:
        print(
            f"Nombre: {empleado['nombre']}, Edad: {empleado['edad']}, "
            f"Salario: {empleado['salario']}, Departamento: {empleado['dpto']}"
        )
    return resultados


def aplicar_aumento_salarial(empleados, empleado_a_buscar, porcentaje=None):
    if porcentaje is None:
        porcentaje = float(input("Ingresar porcentaje: "))

    for empleado in empleados:
        if empleado["nombre"].lower() == empleado_a_buscar.lower():
            aumento = empleado["salario"] * porcentaje / 100
            empleado["salario"] += aumento
            print(
                f"Se aplicó un aumento del {porcentaje}% a {empleado['nombre']}. "
                f"Nuevo salario: {empleado['salario']}"
            )
            return empleado

    print(f"No se encontró al empleado '{empleado_a_buscar}'.")
    return None


def aumento_salarial(empleados, empleado, porcentaje=None):
    return aplicar_aumento_salarial(empleados, empleado, porcentaje)


def obtener_promedio_salarial(empleados):
    if not empleados:
        return 0
    total_salario = sum(empleado["salario"] for empleado in empleados)
    return total_salario / len(empleados)


def promedio_salarial(empleados):
    return obtener_promedio_salarial(empleados)


