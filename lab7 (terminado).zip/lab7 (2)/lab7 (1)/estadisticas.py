def resumen(empleados):
    if not empleados:
        return {
            "total_empleados": 0,
            "edad_promedio": 0,
            "empleados_menor_30": 0,
            "salario_promedio": 0,
            "salario_maximo": 0,
            "salario_minimo": 0,
            "salario_supera_1000": False,
        }

    total_empleados = len(empleados)
    edad_promedio = sum(empleado["edad"] for empleado in empleados) / total_empleados
    empleados_menor_30 = sum(1 for empleado in empleados if empleado["edad"] < 30)
    salario_promedio = sum(empleado["salario"] for empleado in empleados) / total_empleados
    salario_maximo = max(empleado["salario"] for empleado in empleados)
    salario_minimo = min(empleado["salario"] for empleado in empleados)
    salario_supera_1000 = any(empleado["salario"] > 1000 for empleado in empleados)

    return {
        "total_empleados": total_empleados,
        "edad_promedio": edad_promedio,
        "empleados_menor_30": empleados_menor_30,
        "salario_promedio": salario_promedio,
        "salario_maximo": salario_maximo,
        "salario_minimo": salario_minimo,
        "salario_supera_1000": salario_supera_1000,
    }


def mostrar_resumen(empleados):
    datos = resumen(empleados)
    print(f"Cantidad total de empleados: {datos['total_empleados']}")
    print(f"Edad promedio: {datos['edad_promedio']}")
    print(f"Empleados con edad menor a 30: {datos['empleados_menor_30']}")
    print(f"Salario promedio: {datos['salario_promedio']}")
    print(f"Salario máximo: {datos['salario_maximo']}")
    print(f"Salario mínimo: {datos['salario_minimo']}")
    print(
        "¿Algún salario supera los 1000? "
        f"{'Sí' if datos['salario_supera_1000'] else 'No'}"
    )
    return datos

