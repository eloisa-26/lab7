def registrar_empleado(empleados):
    empleado = {
        "nombre": input("Nombre: ").strip(),
        "edad": int(input("Edad: ")),
        "salario": float(input("Salario: ")),
        "departamento": input("Departamento: ").strip(),
    }
    empleados.append(empleado)
    return empleado
