
from unittest import case

import captura
import estadisticas
import funcionalidad

empleado = []  

print("=== Menú Principal ===")
print("1. Ingresar empleados")
print("2. Mostrar empleados")
print("3. Buscar por departamento")
print("4. Aplicar aumento salarial")
print("5. Mostrar estadísticas")
print("6. Salir")

while True:
    opcion = int(input("Seleccione una opción: "))
    match opcion:
        case 1:
            captura.registrar_empleado(empleado)
            print("Empleado registrado exitosamente.")
        case 2:
            funcionalidad.lista_empleados(empleado)
        case 3:
            dpto = input("Ingrese el nombre del departamento a buscar: ")
            funcionalidad.buscar_por_departamento(empleado, dpto)
        case 4:
            nombre = input("Ingrese el nombre del empleado a buscar: ")
            funcionalidad.aplicar_aumento_salarial(empleado, nombre)
        case 5:
            estadisticas.mostrar_resumen(empleado)
        case 6:
            print("Saliendo del programa...")
            break  
        case _:
            print("Opción inválida. Por favor, seleccione una opción válida.")  
